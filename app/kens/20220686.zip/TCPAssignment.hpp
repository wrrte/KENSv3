/*
 * E_TCPAssignment.hpp
 *
 *  Created on: 2014. 11. 20.
 *      Author: Keunhong Lee
 */

#ifndef E_TCPASSIGNMENT_HPP_
#define E_TCPASSIGNMENT_HPP_

#include <E/Networking/E_Host.hpp>
#include <E/Networking/E_Networking.hpp>
#include <E/Networking/E_TimerModule.hpp>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>

#define CLOSE_state 0
#define LISTEN_state 1
#define SYN_RCVD_state 2
#define SYN_SENT_state 3
#define ESTABLISHED_state 4
#define CLOSE_WAIT_state 5
#define FIN_WAIT_1_state 6
#define CLOSING_state 7
#define LAST_ACK_state 8
#define FIN_WAIT_2_state 9
#define TIME_WAIT_state 10

#define SEND_BUFFER_SIZE 131072

namespace E {

class TCPAssignment : public HostModule,
                      private RoutingInfoInterface,
                      public SystemCallInterface,
                      public TimerModule {
private:
  virtual void timerCallback(std::any payload) final;

  uint64_t TCP_state;
  uint64_t seq;

  bool stop;

  struct SocketInfo {
    uint32_t ip;
    uint16_t port;
    bool listen_state;
    int left_connect_place;
    std::deque<std::tuple<uint32_t, uint32_t, uint16_t, uint16_t, UUID>> syn_queue;
    std::list<std::tuple<uint32_t, uint32_t, uint16_t, uint16_t>> accept_queue;
    std::unordered_map<std::pair<int, int>, std::tuple<UUID, struct sockaddr *, socklen_t *>> accept_requests;
    std::list<Packet> read_queue;
    std::list<std::tuple<UUID, void *, size_t>> read_requests;
    std::list<size_t> write_requests;
    int backlog;
    uint32_t peerip;
    uint16_t peerport;
    bool connected;
    uint8_t send_buffer[SEND_BUFFER_SIZE];
    uint32_t sb_pointer;
    uint32_t send_base;
    uint32_t nextseqnum;
    uint32_t peer_seq_num;
    uint32_t data_num;
    uint32_t rwnd;
    uint8_t recv_buffer[1024];
    size_t recv_len;
    uint32_t readacknum;
    bool SimultaneousConnect;
    bool close_signal;
    std::unordered_map<uint32_t, UUID> timerkeys;
  };

  std::unordered_map<std::pair<int, int>, SocketInfo> sock_table;
  std::list<std::tuple<uint32_t, uint32_t, uint16_t, uint16_t>> SYN_queue;
  std::list<std::tuple<uint32_t, uint32_t, uint16_t, uint16_t>> accept_queue;
  std::unordered_map<std::pair<uint32_t, uint16_t>, std::pair<UUID, UUID>> SYNACK_queue;
  std::unordered_map<std::pair<int, int>, std::tuple<UUID, struct sockaddr *, socklen_t *>> accept_requests;

  uint16_t allocateEphemeralPort();

public:
  TCPAssignment(Host &host);
  virtual void initialize();
  virtual void finalize();
  virtual ~TCPAssignment();

protected:
  virtual void systemCallback(UUID syscallUUID, int pid,
                              const SystemCallParameter &param) final;

  void send_ACK(SocketInfo& sock);
                              
  void syscall_read(UUID syscallUUID, int pid, int fd, void *buf, size_t count);
  void syscall_write(UUID syscallUUID, int pid, int fd, void *buf, size_t count);
                            
  void syscall_socket(UUID syscallUUID, int pid, int domain, int type);
  void syscall_listen(UUID syscallUUID, int pid, int sockfd, int backlog);
  void syscall_accept(UUID syscallUUID, int pid, int sockfd, struct sockaddr *addr, socklen_t *addrlen);
  void syscall_bind(UUID syscallUUID, int pid, int sockfd, struct sockaddr *addr, socklen_t addrlen);
  void syscall_connect(UUID syscallUUID, int pid, int sockfd, struct sockaddr *addr, socklen_t addrlen);
  void syscall_getsockname(UUID syscallUUID, int pid, int sockfd, struct sockaddr *addr, socklen_t *addrlen);
  void syscall_getpeername(UUID syscallUUID, int pid, int sockfd, struct sockaddr *addr, socklen_t *addrlen);
  void syscall_close(UUID syscallUUID, int pid, int fd);
  virtual void packetArrived(std::string fromModule, Packet &&packet) final;
};

class TCPAssignmentProvider {
private:
  TCPAssignmentProvider() {}
  ~TCPAssignmentProvider() {}

public:
  static void allocate(Host &host) { host.addHostModule<TCPAssignment>(host); }
};

} // namespace E

#endif /* E_TCPASSIGNMENT_HPP_ */
